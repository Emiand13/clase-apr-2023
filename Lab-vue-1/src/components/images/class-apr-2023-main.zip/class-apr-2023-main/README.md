# class-apr-2023
Estudiando programacion en Ironhack!!!
