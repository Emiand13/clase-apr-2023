<script setup>
import EjercicioSabado2 from './components/EjercicioSabado2.vue'

</script>

<template>
 

  <main>
    <EjercicioSabado2/>
  </main>
</template>

<style scoped>

</style>
