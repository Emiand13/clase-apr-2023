<script></script>

<template>
<div class="myBiography">
    <h1>Mi nombre es Michael Scott</h1>
    <p>Nací en Scranton, Pennsylvania, EE.UU. el 15 de marzo de 1965</p>
    <p>Me gusta gastar bromas constantes a mis compañeros de trabajo y me encanta ser el centro de atención</p>
    <img src="https://upload.wikimedia.org/wikipedia/en/d/dc/MichaelScott.png" alt="Image of Michael Scott." width="300" height="300">

</div>

</template>

<style>

.myBiography{

    color:blue;
}

</style>