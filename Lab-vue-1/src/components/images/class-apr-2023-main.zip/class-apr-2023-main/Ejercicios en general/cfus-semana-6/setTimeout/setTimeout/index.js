
// setTimeout

setTimeout(() => {
    console.log("Hello, World!");
},3000);