
// Instrucciones
// ¡Intenta averiguar cuál será el resultado de la expresión!

const expressionOne = ((2 * 2) + 5) * 6;
console.log(expressionOne); // 54
 
const expressionTwo = ((2* 2) + (5 * 3)) - 5;
console.log(expressionTwo); // 14
 
const expressionThree = (5 * 5) / (5 * 5);
console.log(expressionThree); // 1
 
const expressionFour = 5 * 5 - 5 * 4;
console.log(expressionFour); // 5
