
// Instrucciones
// Crea una declaración condicional que compruebe si una variable llamada age ha sido asignada a un valor o no (si es undefined). Si su valor es undefined, imprime en la consola “Age is not defined” (“Edad no está definida”). De lo contrario, imprime en la consola Age is defined (“Edad está definida”)

// La edad no esta definida
let edad;
// let age = 40;
 
if (edad === undefined){
  console.log("edad no esta definida");
} else {
  console.log("Edad está definida");
}


// La edad esta definida

 let age = 40;
 
if (age === undefined){
  console.log("age is undefined");
} else {
  console.log("age is defined");
}