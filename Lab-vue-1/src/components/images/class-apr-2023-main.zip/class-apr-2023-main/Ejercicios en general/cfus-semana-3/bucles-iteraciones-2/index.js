

// Bucles e Iteraciones #2
// Instrucciones
// Crea un bucle for que cuente del 0 al 20. En cada iteración, comprueba si el número actual es par o impar, y escríbelo en la consola.

for (let i = 0; i <= 20; i++) {
    if (i % 2 === 0) {
      console.log(i + " is even");
    } else {
      console.log(i + " is odd");
    }
  }