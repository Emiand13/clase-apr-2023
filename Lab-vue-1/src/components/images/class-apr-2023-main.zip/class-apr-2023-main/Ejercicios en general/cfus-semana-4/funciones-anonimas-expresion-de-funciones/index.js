

// En esta linea de codigo definimos una funcion anonima llamada "agregar" que toma dos parametros "x e y" y nos devuelve la suma de los dos parametros (return x + y).
const agregar = function (x, y) {
    return  x + y;
  };
console.log(agregar(5, 5)); 

// En esta linea de codigo defininos una funcion anonima llamada "multiplicar" que toma dos parametros "x e y" y nos devuelve la multiplicacion de los dos parametros (return x * y).

const multiplicar = function (x, y) {
    return x * y;
  };
console.log(multiplicar(5, 5)); 

// En esta linea de codigo definimos una funcion anonima llamada "divide" que toma dos parametros "x e y" y nos devuelve la division de los dos parametros (return x / y).
const divide = function (x, y) {
    return x / y;
  };
console.log(divide(5, 5)); 
