<script setup>
import Lab1 from './components/Lab1.vue'

</script>

<template>
 

  <main>
    <Lab1 />
  </main>
</template>

<style scoped>

</style>
