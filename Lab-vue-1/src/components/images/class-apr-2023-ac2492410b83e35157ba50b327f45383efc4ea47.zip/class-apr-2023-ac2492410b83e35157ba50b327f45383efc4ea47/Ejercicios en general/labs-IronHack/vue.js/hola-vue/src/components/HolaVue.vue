<script setup>



</script>

<template>
    <div>
    <img class="Ironhack_logo" src="../images/Ironhack_logo.png">
    <img class="Burguer_menu" src="../images/Burger_menu.png">
    <img class="Vue_logo" src="../images/Vue_logo.png">

    <img class="Welcome" src="../images/Welcome to Vue.js.png">
    <img class="Become" src="../images/Become a coding ninja with the fastest-growing JavaScript framework.png">
    <img class="Buttton_shape" src="../images/Buttton shape.png">
    <img class="Button_text" src="../images/Button text.png">
    <img class="Background" src="../images/Background.png">
    <img class="Usp-1" src="../images/USP-1.png">
    <img class="Performant" src="../images/Performant.png">
    <img class="Truly" src="../images/Truly reactive, compiler-optimized rendering system that rarely requires manual optimization..png">
    <img class="Usp-2" src="../images/USP-2.png">
    <img class="Approachable" src="../images/Approachable.png">
    <img class="Builds " src="../images/Builds on top of standard HTML, CSS and JavaScript with intuitive API and world-class documentation..png">
    <img class="Usp-3" src="../images/USP-3.png">
    <img class="Versatile" src="../images/Versatile.png">

<img class="Rich" src="../images/A rich, incrementally adoptable ecosystem that scales between a library and a full-featured framework..png">
</div>

    


    
</template>

<style scoped>
/* Ironhack_logo */
.Ironhack_logo{
  position: absolute;
  width: 35px;
  height: 38px;
  left: 30px;
  top: 20px;
  }



  /* Burger_menu */

.Burguer_menu{position: absolute;
width: 22px;
height: 20px;
left: 548px;
top: 29px;
}

.Vue_logo{/* Vue_logo */


position: absolute;
width: 129px;
height: 129px;
left: 235px;
top: 86px;
}

.Welcome{
/* Welcome to Vue.js */

position: absolute;
width: 446px;
height: 48px;
left: 82px;
top: 250px;

font-family: 'Inter';
font-style: normal;
font-weight: 800;
font-size: 50px;
line-height: 95px;
/* or 190% */

display: flex;
align-items: center;
text-align: center;
letter-spacing: -0.02em;

color: #2B2F30;

}
/* Become a coding ninja with the fastest-growing JavaScript framework */
.Become{


position: absolute;
width: 309px;
height: 40px;
left: 145px;
top: 300px;

font-family: 'Inter';
font-style: normal;
font-weight: 800;
font-size: 14px;
line-height: 20px;
/* or 143% */

display: flex;
align-items: center;
text-align: center;
letter-spacing: -0.02em;

color: #000000;}

/* Buttton shape */
.Buttton_shape{

position: absolute;
width: 121px;
height: 31px;
left: 239px;
top: 354px;

background: #34495E;
border-radius: 13px;

}

/* Button text */
.Button_text{

position: absolute;
width: 72px;
height: 13px;
left: 264px;
top: 362px;

font-family: 'Inter';
font-style: normal;
font-weight: 800;
font-size: 14px;
line-height: 20px;
/* identical to box height, or 143% */

display: flex;
align-items: center;
text-align: center;
letter-spacing: -0.02em;

color: #FFFFFF;



}
/* Background */
.Background{
position: absolute;
width: 600px;
height: 312px;
left: 0px;
top: 450px;

background: #39B983;

}

/* USP-1 */
.Usp-1{

position: absolute;
width: 60px;
height: 60px;
left: 88px;
top: 509px;
    
}
.Performant{
    
position: absolute;
width: 87px;
height: 15px;
left: 75px;
top: 580px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 16px;
line-height: 95px;
/* identical to box height, or 594% */

display: flex;
align-items: center;
text-align: center;
letter-spacing: -0.02em;

color: #000000;
}

.Truly{

position: absolute;
width: 125px;
height: 91px;
left: 56px;
top: 620px;

font-family: 'Inria Sans';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* or 142% */

display: flex;
align-items: center;
text-align: center;
letter-spacing: -0.02em;

color: #000000;
}

.Usp-2{
position: absolute;
width: 60px;
height: 60px;
left: 270px;
top: 509px;



}

.Approachable{
    
position: absolute;
width: 107px;
height: 16px;
left: 246px;
top: 582px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 16px;
line-height: 95px;
/* identical to box height, or 594% */

display: flex;
align-items: center;
text-align: center;
letter-spacing: -0.02em;

color: #000000;
}

.Builds{

    position: absolute;
width: 125px;
height: 91px;
left: 237px;
top: 620px;

font-family: 'Inria Sans';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* or 142% */

display: flex;
align-items: center;
text-align: center;
letter-spacing: -0.02em;

color: #000000;


}

.Usp-3{
position: absolute;
width: 60px;
height: 60px;
left: 437px;
top: 509px;

}

.Versatile{
position: absolute;
width: 68px;
height: 15px;
left: 437px;
top: 580px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 16px;
line-height: 95px;
/* identical to box height, or 594% */

display: flex;
align-items: center;
text-align: center;
letter-spacing: -0.02em;

color: #000000;

}

.Rich{


    position: absolute;
width: 125px;
height: 91px;
left: 409px;
top: 620px;

font-family: 'Inria Sans';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* or 142% */

display: flex;
align-items: center;
text-align: center;
letter-spacing: -0.02em;

color: #000000;
}

</style>

