<script setup>
import HolaVue from './components/HolaVue.vue'

</script>

<template>


 
    
    <HolaVue/>  
  
</template>

<style scoped>

</style>
