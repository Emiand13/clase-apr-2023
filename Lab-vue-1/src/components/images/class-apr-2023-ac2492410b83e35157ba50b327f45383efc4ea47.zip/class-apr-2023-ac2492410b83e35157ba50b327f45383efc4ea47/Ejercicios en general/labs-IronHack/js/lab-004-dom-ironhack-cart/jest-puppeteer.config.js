module.exports = {
  server: {
    command: 'serve . -l 4444',
    port: 4444
  }
};
