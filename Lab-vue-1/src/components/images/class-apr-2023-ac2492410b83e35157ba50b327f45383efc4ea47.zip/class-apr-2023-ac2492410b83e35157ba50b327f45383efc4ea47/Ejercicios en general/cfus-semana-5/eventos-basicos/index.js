

// Uso de escuchadores de eventos #1

const button = document.getElementById("my-button");

button.addEventListener("click", () => {
    console.log("Button clicked!");
  });



