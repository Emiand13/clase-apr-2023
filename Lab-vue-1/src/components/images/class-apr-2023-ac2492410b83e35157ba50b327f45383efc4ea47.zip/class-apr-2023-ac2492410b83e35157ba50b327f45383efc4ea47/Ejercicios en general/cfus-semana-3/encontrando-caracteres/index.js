
// Instrucciones
// Escribe un código que encuentre el índice de la letra j en My favorite dessert is jello.
// Puedes utilizar el método indexOf para encontrar el índice de un carácter específico en una cadena de texto.


let string = "My favorite dessert is jello";
let index = string.indexOf("j");
console.log(index); // 23

// Esto imprimirá 23 en la consola, que es el índice de la letra j en la cadena. Si la letra j no se encuentra en la cadena, indexOf devolverá -1