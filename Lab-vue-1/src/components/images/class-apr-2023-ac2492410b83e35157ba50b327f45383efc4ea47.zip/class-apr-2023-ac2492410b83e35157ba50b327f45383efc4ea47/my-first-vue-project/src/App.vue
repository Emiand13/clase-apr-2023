<script setup>
import ShortBiography from "./components/ShortBiography.vue"
</script>

<template>
  <ShortBiography/>
</template>

<style>

</style>
