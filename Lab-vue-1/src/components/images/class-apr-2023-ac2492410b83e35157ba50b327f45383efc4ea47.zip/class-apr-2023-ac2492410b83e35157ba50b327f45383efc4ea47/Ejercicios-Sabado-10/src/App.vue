<script setup>

import EjercicioSabado from './components/EjerciciosSabado.vue'
</script>

<template>


   <main><EjercicioSabado/></main>

</template>

<style scoped>

</style>
